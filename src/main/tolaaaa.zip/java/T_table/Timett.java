package T_table;

public class Timett {
	
	private int id;
	private String ex;
	private String b;
	private String m;
	private String d;
	private String t;

	public Timett(int id, String ex, String b, String m, String d, String t) {
		
		this.id = id;
		this.ex = ex;
		this.b = b;
		this.m = m;
		this.d = d;
		this.t = t;
		
	}


	public int getId() {
		return id;
	}


	public String getEx() {
		return ex;
	}


	public String getB() {
		return b;
	}


	public String getM() {
		return m;
	}


	public String getD() {
		return d;
	}


	public String getT() {
		return t;
	}
	

}
